﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtShow.Text += "1";
        }

        private void Calculator_Enter(object sender, EventArgs e)
        {
            //txtShow.Text = "";
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            txtShow.Text += "8";
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            txtShow.Text += "1";
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtShow.Text += "0";
        }

        private void btnPoint_Click(object sender, EventArgs e)
        {
            txtShow.Text += ".";
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            txtShow.Text += "2";
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            txtShow.Text += "3";
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            txtShow.Text += "4";
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            txtShow.Text += "5";
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            txtShow.Text += "6";
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            txtShow.Text += "7";
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            txtShow.Text += "9";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtShow.Clear();
        }
        double num1 = 0;
        double num2 = 0;
        double ans = 0;
        int opp;
        double[] memory = new double [10];
        int count = -1;

        private void btnAdd_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtShow.Text);
            txtShow.Text = "";
            opp = 1;
        }


        private void btnEqual_Click(object sender, EventArgs e)
        {
            num2 = Double.Parse(txtShow.Text);
            switch(opp)
            {
                case 1:
                    ans = num1 + num2;
                    txtShow.Text = ans.ToString();
                    break;
                case 2:
                    ans = num1 - num2;
                    txtShow.Text = ans.ToString();
                    break;
                case 3:
                    ans = num1 * num2;
                    txtShow.Text = ans.ToString();
                    break;
                case 4:
                    if (num2 == 0)
                        MessageBox.Show("Cannot Divide by 0", "Syntax Error");
                    else if (num1 == 0)
                        txtShow.Text = "Infinite(∞)";
                    else
                    {
                        ans = num1 / num2;
                        txtShow.Text = ans.ToString();
                    }
                    break;
            }
            memory[count+1] = ans;
            count++;

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtShow.Text);
            txtShow.Text = "";
            opp = 2;
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtShow.Text);
            txtShow.Text = "";
            opp = 3;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtShow.Text);
            txtShow.Text = "";
            opp = 4;
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            if (txtShow.Text.Length > 0)
                txtShow.Text = txtShow.Text.Remove(txtShow.Text.Length - 1, 1);
        }

        private void btnMR_Click(object sender, EventArgs e)
        {
            if (count < 0)
                MessageBox.Show("Memory Recall Function is Empty", "Error");
            else
            {
                txtShow.Text = memory[count].ToString();
                count--;
            } 
        }
    }
}
